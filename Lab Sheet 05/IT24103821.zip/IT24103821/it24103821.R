setwd("C:\\Users\\Malee\\OneDrive\\Desktop\\IT24103821")
getwd()

Delivery_Times <- read.table("Exercise - Lab 05.txt",header=TRUE,stringsAsFactors = FALSE)




head(Delivery_Times)
hist(Delivery_Times$Delivery_Time_.minutes.,
  main = "Histogram for delivery times",
  xlab ="Delivery time(minute",
  breaks =seq(20,70,length.out=10),
  right =FALSE,
  col ="skyblue" ,
  border ="black"
  )


times <-Delivery_Times$Delivery_Time_.minutes.
breaks <-seq(20,70,length.out =10)  
freq <- hist(times, breaks = breaks,right =FALSE,plot =FALSE)  
cum_freq <-cumsum(freq$counts)

plot(breaks[-1], cum_freq,type ="o",col="blue",lwd=2,pch=16,
     main="Cumulative Frequency polygon(Ogive)",
     xlab= "Delivery time(minute)",
     ylab ="cumulative Frequency")

grid()
