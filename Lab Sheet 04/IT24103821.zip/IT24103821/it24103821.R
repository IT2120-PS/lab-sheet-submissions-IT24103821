setwd("C:\\Users\\it24103821\\Documents\\IT24103821")
branch_data <-read.table("Exercise.txt",header=TRUE,sep=",")


head(branch_data)


boxplot(branch_data$Sales, main = "boxplot of sales", ylab= "Sales", col= "lightblue")


fivenum(branch_data$Advertising)
summary(branch_data$Advertising)
IQR(branch_data$Advertising)


find_outliers<-function(x){}
Q1<- quantile(x,0.25)
Q3 <- QUANTILE(X,0.75)
iqr<-Q3-Q1

lower <-Q1 -1.5*IQR
upper<-Q3 +1.5*IQR
outliers <-x[x<lower|x>upper]
return(outliers)
  
}


